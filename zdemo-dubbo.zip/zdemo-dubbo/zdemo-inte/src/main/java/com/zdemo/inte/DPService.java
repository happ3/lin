package com.zdemo.inte;

public interface DPService {
	public String getName(String name);
}
