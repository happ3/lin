## Sohouer-Datasource


![Sohouer](http://7xla3f.com1.z0.glb.clouddn.com/logo3@.png)

###  Sohouer-Datasource 主要功能：

* 可用于数据库读写分离 ，业务分库、分表 （不支持水平分表）。
* 支持 1 主 n 从，n 可以为 0 。从库负载均衡基于随机软负载算法实现。
* 通过注解 @DataSource 可指定主、从库 , 默认主库

###  Sohouer-Datasource 内部依赖：

* [spring-boot-starter-aop](http://spring.io/)  

>  Sohouer-Framework 基于 Spring-boot 构建 ， Sohouer-Datasource 通过 @DataSource 指定主、从库数据源的实现基于 Spring AOP 。

* [spring-boot-starter-jdbc](http://spring.io/)  
> Sohouer-Framework 动态数据源切换实现基于 org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource
* [druid](https://github.com/alibaba/druid)
> Sohouer-Framework 采用的数据库连接池是 druid ，目前 Sohouer-Framework 对 druid 部分数据库相关配置进行了屏蔽



### 示例项目：

TODO

### 配置说明：

> classpath:dataSource.properties

```
# 主库配置
dataSource.master.url: jdbc:mysql://master:3306/sohouer?characterEncoding=utf8
dataSource.master.driverClassName: com.mysql.jdbc.Driver
dataSource.master.username: root
dataSource.master.password: root
dataSource.master.maxActive: 100
dataSource.master.minIdle: 5
dataSource.master.initialSize: 5
dataSource.master.minEvictableIdleTimeMillis:600000
# 从库配置 , 多个从库的账号、密码必须一致 。如果只用 单个 mysql 节点 ，不需要从库配置
dataSource.slave.urls: jdbc:mysql://slave1:3306/sohouer?characterEncoding=utf8 , jdbc:mysql://slave2:3306/sohouer?characterEncoding=utf8
dataSource.slave.driverClassName: com.mysql.jdbc.Driver
dataSource.slave.username: root
dataSource.slave.password: root
dataSource.slave.maxActive: 100
dataSource.slave.minIdle: 5
dataSource.slave.initialSize: 5
dataSource.slave.minEvictableIdleTimeMillis:600000

```

### 未来可能

* 从库负载均衡支持可选更丰富的实现算法，比如 最少连接 、最快算法、 观察算法 等负载算法，实现更灵活、更合理的从库负载均衡，提升数据源的可用性及性能
* 业务方需求急切的未满足特性
