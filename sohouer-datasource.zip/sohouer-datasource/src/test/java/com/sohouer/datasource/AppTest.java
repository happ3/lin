package com.sohouer.datasource;

import javax.annotation.Resource;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = App.class)
public class AppTest extends TestCase {
	@Resource
	private DynamicDataSource dataSource;

	@org.junit.Test
	@DataSource
	public void dataSourceTest() {
		System.out.println(dataSource);
	}
}
