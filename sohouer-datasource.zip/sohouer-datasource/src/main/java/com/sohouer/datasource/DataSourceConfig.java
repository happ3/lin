package com.sohouer.datasource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.util.ObjectUtils;

import com.alibaba.druid.pool.DruidDataSource;

/**
 * 数据源配置
 * 
 * @Description: 支持 1 主 n 从 ，n 可以为 0
 * @author yintengfei ytf@sohouer.com
 * @date 2016年5月14日 上午10:39:37
 */
@Configuration
@ConfigurationProperties(prefix = "dataSource")
@PropertySource(value = { "classpath:dataSource.properties" })
@AutoConfigureAfter(value = PropertySourcesPlaceholderConfigurer.class)
public class DataSourceConfig {

	private static final Log logger = LogFactory.getLog(DataSourceConfig.class);

	public final static List<String> slaveUrlHashCodes = new ArrayList<>();

	private final static String SLAVE_PREFIX = "slave_";
	
	/**
	 * 主库数据源相关配置参数
	 * 
	 * @return
	 */
	@Bean()
	@ConfigurationProperties(prefix = "dataSource.master")
	public DataSourceConfigParam masterDataSourceConfigParam() {
		return new DataSourceConfigParam();
	}

	/**
	 * 从库数据源相关配置参数
	 * 
	 * @return
	 */
	@Bean()
	@ConfigurationProperties(prefix = "dataSource.slave")
	public DataSourceConfigParam slaveDataSourceConfigParam() {
		return new DataSourceConfigParam();
	}

	/**
	 * 主库数据源
	 * 
	 * @param masterDataSourceConfigParam
	 *            主库数据源相关配置参数
	 * @return
	 */
	@Bean()
	public DataSource masterDataSource(DataSourceConfigParam masterDataSourceConfigParam) {
		if (logger.isDebugEnabled()) {
			logger.debug("before init masterDataSource ，masterDataSourceConfigParam："
					+ masterDataSourceConfigParam.toString());
		}
		logger.debug(masterDataSourceConfigParam);
		DruidDataSource masterDataSource = new DruidDataSource();
		masterDataSource.setUrl(masterDataSourceConfigParam.getUrl());
		masterDataSource.setDriverClassName(masterDataSourceConfigParam.getDriverClassName());
		masterDataSource.setUsername(masterDataSourceConfigParam.getUsername());
		masterDataSource.setPassword(masterDataSourceConfigParam.getPassword());
		masterDataSource.setMaxActive(masterDataSourceConfigParam.getMaxActive());
		masterDataSource.setMinIdle(masterDataSourceConfigParam.getMinIdle());
		masterDataSource.setInitialSize(masterDataSourceConfigParam.getInitialSize());
		masterDataSource.setMinEvictableIdleTimeMillis(masterDataSourceConfigParam.getMinEvictableIdleTimeMillis());
		return masterDataSource;
	}

	/**
	 * 从库数据源
	 * 
	 * @Description：通过 从库数据源配置信息构造 DataSource ，hashcodeSlaveUrls 存储 url
	 *                 的hashCode 以供软负载从库。
	 * @param slaveDataSourceConfigParam
	 * @return 可能为 null
	 */
	public Map<String, DruidDataSource> slaveDataSourceMap(DataSourceConfigParam slaveDataSourceConfigParam) {
		if (logger.isDebugEnabled()) {
			logger.debug("before init slaveDataSourceMap ，slaveDataSourceConfigParam："
					+ slaveDataSourceConfigParam.toString());
		}
		String[] slaveUrls = ObjectUtils.isEmpty(slaveDataSourceConfigParam.getUrls()) ? null
				: slaveDataSourceConfigParam.getUrls().split(",");
		if (!ObjectUtils.isEmpty(slaveUrls)) {
			Map<String, DruidDataSource> slaveDataSourceMap = new HashMap<>();
			int i = 1;
			for (String slaveUrl : slaveUrls) {
				String url = slaveUrl.trim();
				// urlHashCode = slave_i_-233232123
				String urlHashCode = new String(SLAVE_PREFIX + i++ + "_" + url.hashCode());
				slaveUrlHashCodes.add(urlHashCode);
				DruidDataSource slaveDataSource = new DruidDataSource();
				slaveDataSource.setUrl(url);
				slaveDataSource.setDriverClassName(slaveDataSourceConfigParam.getDriverClassName());
				slaveDataSource.setUsername(slaveDataSourceConfigParam.getUsername());
				slaveDataSource.setPassword(slaveDataSourceConfigParam.getPassword());
				slaveDataSource.setMaxActive(slaveDataSourceConfigParam.getMaxActive());
				slaveDataSource.setMinIdle(slaveDataSourceConfigParam.getMinIdle());
				slaveDataSource.setInitialSize(slaveDataSourceConfigParam.getInitialSize());
				slaveDataSource
						.setMinEvictableIdleTimeMillis(slaveDataSourceConfigParam.getMinEvictableIdleTimeMillis());
				slaveDataSourceMap.put(urlHashCode, slaveDataSource);
			}
			return slaveDataSourceMap;
		} else {
			return null;
		}
	}

	/**
	 * 动态数据源
	 * 
	 * @param master
	 * @return
	 */
	@Bean
	@Primary
	public DynamicDataSource dynamicDataSource( DataSource masterDataSource,
			DataSourceConfigParam slaveDataSourceConfigParam) {
		DynamicDataSource dynamicDataSource = new DynamicDataSource();
		dynamicDataSource.setTargetDataSources(targetDataSources(masterDataSource, slaveDataSourceConfigParam));
		dynamicDataSource.setDefaultTargetDataSource(masterDataSource);
		return dynamicDataSource;
	}
	
	/**
	 * 构造目标主从数据源
	 * 
	 * @Description :
	 * 
	 * @param masterDataSource
	 * @param slaveDataSourceMap
	 * @return
	 */
	public Map<Object, Object> targetDataSources(DataSource masterDataSource,
			DataSourceConfigParam slaveDataSourceConfigParam) {
		Map<Object, Object> targetDataSources = new HashMap<Object, Object>();
		targetDataSources.put(DataSourceType.MASTER.type(), masterDataSource);
		Map<String, DruidDataSource> slaveDataSourceMap = slaveDataSourceMap(slaveDataSourceConfigParam);
		if (slaveDataSourceMap != null) {
			for (String slaveUrlHashCode : slaveUrlHashCodes) {
				DataSource slaveDataSource = slaveDataSourceMap.get(slaveUrlHashCode);
				targetDataSources.put(slaveUrlHashCode, slaveDataSource);
			}
		}
		return targetDataSources;
	}
}