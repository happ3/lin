package com.sohouer.datasource;

public class SlaveDataSourceMap {

}
