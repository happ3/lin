package com.sohouer.datasource;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 动态数据源
 * 
 * @Description: TODO
 * @author yintengfei ytf@sohouer.com
 * @date 2016年5月14日 上午12:01:35
 */
public class DynamicDataSource extends AbstractRoutingDataSource {

	Logger log = LoggerFactory.getLogger(DynamicDataSource.class);

	protected Object determineCurrentLookupKey() {
		if (log.isInfoEnabled()) {
			log.info("dataSource is {}", DynamicDataSourceHolder.getDataSouce());
		}
		if (DynamicDataSourceHolder.getDataSouce() != null) {
			return DynamicDataSourceHolder.getDataSouce();
		}
		return DataSourceType.MASTER.type();
	}
}

/**
 * 动态数据源决策者
 * 
 * @Description: 根据 DataSource 的 value 决定使用 主库 或 从库
 * @author yintengfei ytf@sohouer.com
 * @date 2016年5月14日 上午12:01:16
 */
class DynamicDataSourceHolder {
	private static final ThreadLocal<String> holder = new ThreadLocal<String>();

	/**
	 * 选取主从
	 * 
	 * @Description : 如果是从库，将根据随机负载算法选取从库
	 * @param dsType
	 * @author yintengfei ytf@sohouer.com
	 * @date 2016年5月14日 上午12:02:19
	 */
	public static void setDataSource(DataSourceType dsType) {
		switch (dsType) {
		case MASTER:
			holder.set(dsType.type());
			break;
		case SLAVE:
			final int slaveNum = DataSourceConfig.slaveUrlHashCodes.size();
			Random random = new Random();
			int randomSlaveIndex = random.nextInt(slaveNum);
			holder.set(DataSourceConfig.slaveUrlHashCodes.get(randomSlaveIndex));
		default:
			break;
		}
	}

	public static String getDataSouce() {
		return holder.get();
	}
}
