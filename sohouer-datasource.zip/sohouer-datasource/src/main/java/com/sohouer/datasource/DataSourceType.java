package com.sohouer.datasource;

/**
 * 数据源类型
 * 
 * @author yin
 *
 */
public enum DataSourceType {
	MASTER("master"), SLAVE("slave");

	private final String type;

	DataSourceType(String type) {
		this.type = type;
	}

	@DataSource(value = DataSourceType.MASTER)
	public void find() {

	}

	public String type() {
		return type;
	}
}
